/* Ersatz fuer mGBAs generierte version.c (sonst via CMake/git erzeugt). */
#include <mgba/core/version.h>

MGBA_EXPORT const char* const gitCommit = "anycade";
MGBA_EXPORT const char* const gitCommitShort = "anycade";
MGBA_EXPORT const char* const gitBranch = "master";
MGBA_EXPORT const int gitRevision = 0;
MGBA_EXPORT const char* const binaryName = "mgba";
MGBA_EXPORT const char* const projectName = "mGBA";
MGBA_EXPORT const char* const projectVersion = "0.11.0";
