Anycade - mGBA Corresponding Source

This archive contains the exact mGBA source files distributed in the matching
Anycade Android release. mGBA is licensed under the Mozilla Public License 2.0.
The full license is included as mgba/LICENSE.

The Anycade application and its separately written JNI integration are not part
of this source archive. MPL 2.0 applies at file level and does not require those
separate files to be published.

Upstream project: https://github.com/mgba-emu/mgba
Anycade privacy and contact: https://kaozra.github.io/anycade-privacy/

Build identification:
- mGBA project version: 0.11.0
- The archive filename identifies the corresponding Anycade release.
